<?php

echo "INIT EXECUTION<br><br>";


include_once("com/cart/cart.php");



//AddToCart('2', 10);



UserRegister('DNI','NOmbre')





?>